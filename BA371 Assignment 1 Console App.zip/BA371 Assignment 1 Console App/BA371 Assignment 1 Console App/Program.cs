﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BA371_Assignment_1_Console_App
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Compound Interest Grapher\n");

            string path = @"C:\\temp\\out.txt";


            decimal startingCapital1 = UserInput1();
            decimal lowInterest1 = UserInput2();
            decimal highInterest1 = UserInput3();
            int interestIntervals1 = UserInput4();
            int numberOfPeriods = UserInput5();


            System.IO.StreamReader Reader = null;
            try
            {
                Reader = new System.IO.StreamReader("C:\\temp\\in.txt");
            }
            catch
            {
                Console.WriteLine();
                Console.WriteLine("Error opening 'in' file...");
                Console.WriteLine();
                Console.WriteLine("Press Enter to Quit.");
                Console.ReadLine();
                Environment.Exit(1);
            }
            System.IO.StreamWriter file = null;
            try
            {
                file = new System.IO.StreamWriter("c:\\temp\\out.txt", false);

            }
            catch
            {
                Console.WriteLine("Error opening 'out' file...\n");
                Console.WriteLine("Press Enter to Quit");
                Console.ReadLine();
                Environment.Exit(1);
            }

            file.Close();

            string appendText = "<html>" + Environment.NewLine + "<head>" + Environment.NewLine + "<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\" ></ script >"
                 + Environment.NewLine + "<script type=\"text / javascript\">" + Environment.NewLine + "google.load(\"visualization\", \"1\", { packages:[\"linechart\"]});" + Environment.NewLine + "google.setOnLoadCallback(drawChart);"
                 + Environment.NewLine + "function drawChart() {" + Environment.NewLine + "var data = google.visualization.arrayToDataTable([" + Environment.NewLine;
            File.AppendAllText(path, appendText);

            decimal avgInterest = highInterest1 - lowInterest1;
            decimal interestPerPeriod = avgInterest / interestIntervals1;
            double lowInterest = Convert.ToDouble(lowInterest1);
            double amount;
            double numOfPeriods = Convert.ToDouble(numberOfPeriods);
            double startCapital1 = Convert.ToDouble(startingCapital1);
            double interestPerPeriod1 = Convert.ToDouble(interestPerPeriod);
            double interestPerPeriod2;

            

            using (StreamWriter Writer1 = new StreamWriter("c:\\Temp\\out.txt", true))
            {
                int i = 1;
                int j = 1;
                double[] interestArray = new double[100];              
                Writer1.WriteLine(" __________________________ ");
                Writer1.WriteLine("|Periods|Interest Intervals|");
                Writer1.WriteLine("|_______|__________________|");
                Writer1.Write("       {0, 2:0.00}", lowInterest);
                do
                {
                   interestPerPeriod2 = ((interestPerPeriod1 * i) + lowInterest);
                   Writer1.Write("{0, 12:0.00}", interestPerPeriod2);
                   interestArray[i] = interestPerPeriod2;
                   i++;
                } while (i <= interestIntervals1);

                Writer1.WriteLine("");
                Writer1.Write("         ");
                i = 1;
                do
                {
                    
                    amount = startCapital1 * Math.Pow((1 + interestArray[i]), numberOfPeriods);
                    
                    Writer1.Write("{0, 12:0.00}", amount);
                    i++;
                } while (i <= interestIntervals1);
                    
                    
               

                

               
            }





            using (StreamWriter Writer2 = new StreamWriter("c:\\Temp\\out.txt", true))
            {
                
            }

            








            Console.ReadLine();
        }

        static decimal UserInput1()
        {
            bool isInputValid;
            decimal inputValid;
            decimal maxStartingCapital = 1000;
            do
            {
                Console.Write("Please enter the starting captial ( <=1000 ): ");
                isInputValid = decimal.TryParse(Console.ReadLine(), out inputValid)
                   && inputValid <= maxStartingCapital;
                if (!isInputValid)
                {
                    Console.WriteLine("That is not a valid value, please try again.\n");
                }
            } while (!isInputValid);
            return inputValid;
        }

        static Decimal UserInput2()
        {
            bool isInputValid;
            decimal inputValid;
            decimal maxLowInterest = 10.0m;
            do
            {
                Console.Write("Please enter the low interest rate ( in percent! <=10.0 ): ");
                isInputValid = decimal.TryParse(Console.ReadLine(), out inputValid)
                    && inputValid <= maxLowInterest;
                if (!isInputValid)
                {
                    Console.WriteLine("That is not a valid value, please try again.\n");
                }
            } while (!isInputValid);
            return inputValid;
        }

        static Decimal UserInput3()
        {
            bool isInputValid;
            decimal inputValid;
            decimal maxLowInterest = 10.0m;
            do
            {
                Console.Write("Please enter the high interest rate ( in percent! <=10.0 ): ");
                isInputValid = decimal.TryParse(Console.ReadLine(), out inputValid)
                    && inputValid <= maxLowInterest;
                if (!isInputValid)
                {
                    Console.WriteLine("That is not a valid value, please try again.\n");
                }
            } while (!isInputValid);
            return inputValid;
        }

        static int UserInput4()
        {
            bool isInputValid;
            int inputValid;
            int maxInterestIntervals = 25;
            do
            {
                Console.Write("Please enter the number of interest intervals ( <=25 ): ");
                isInputValid = int.TryParse(Console.ReadLine(), out inputValid)
                    && inputValid <= maxInterestIntervals;
                if (!isInputValid)
                {
                    Console.WriteLine("That is not a valid value, please try again.\n");
                }
            } while (!isInputValid);
            return inputValid;
        }

        static int UserInput5()
        {
            bool isInputValid;
            int inputValid;
            int maxPeriods = 25;
            do
            {
                Console.Write("Please enter the number of periods ( <=25 ): ");
                isInputValid = int.TryParse(Console.ReadLine(), out inputValid)
                    && inputValid <= maxPeriods;
                if (!isInputValid)
                {
                    Console.WriteLine("That is not a valid value, please try again.\n");
                }
            } while (!isInputValid);
            return inputValid;
        }

       
    }
}
